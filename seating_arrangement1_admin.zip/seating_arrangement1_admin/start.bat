@echo off
title Seating Arrangement System
color 0A

echo ============================================
echo    AUTOMATIC SEATING ARRANGEMENT SYSTEM
echo ============================================
echo.

REM ---- STEP 1: Start XAMPP ----
echo [1/4] Starting XAMPP...
cd /d C:\xampp
if exist xampp_start.exe (
    start /B xampp_start.exe
    echo       XAMPP Started!
) else (
    echo       XAMPP not found at C:\xampp
    echo       Please check XAMPP installation path!
    pause
    exit
)

REM ---- STEP 2: Wait for XAMPP to load ----
echo [2/4] Waiting for XAMPP to load...
timeout /t 4 /nobreak > nul
echo       XAMPP Ready!

REM ---- STEP 3: Start Flask ----
echo [3/4] Starting Flask Server...
cd /d "C:\Users\ewsar\OneDrive\Desktop\seating_arrangement"
if exist app.py (
    start /B python app.py
    echo       Flask Started!
) else (
    echo       app.py not found!
    echo       Please check your project folder path!
    pause
    exit
)

REM ---- STEP 4: Wait for Flask to start ----
echo [4/4] Waiting for Flask to start...
timeout /t 3 /nobreak > nul

REM ---- STEP 5: Open Browser ----
echo.
echo ============================================
echo    System is Ready!
echo    Opening browser...
echo ============================================
echo.
start chrome http://127.0.0.1:5000

echo    Browser opened!
echo    First time setup? Run: python create_admin.py
echo.
echo    Press any key to STOP the server...
pause > nul

REM ---- STOP SERVER ----
echo.
echo Stopping Flask server...
taskkill /F /IM python.exe > nul 2>&1
echo Stopping XAMPP...
cd /d C:\xampp
if exist xampp_stop.exe (
    start /B xampp_stop.exe
)
echo Server Stopped! Goodbye!
timeout /t 2 /nobreak > nul